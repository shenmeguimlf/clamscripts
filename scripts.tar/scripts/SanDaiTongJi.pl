#!/usr/bin/perl
use strict;
use warnings;
#use lib "/hwfssz1/ST_OCEAN/USER/haoshijie/software/perllib/share/perl5/";
use Getopt::Long;
use List::Util qw(sum);
use POSIX;
use Excel::Writer::XLSX;
use File::Basename;
my ($fastq,$fasta,$name,$outdir,$help);
GetOptions(
        "fastq"=>\$fastq,
        "fasta"=>\$fasta,#default
        "names=s"=>\$name, #"name1;name2;name3"
        "outdir=s"=>\$outdir,
        "help"=>\$help
        );
sub help{
    print <<USAGE;
usage:
    perl $0 --fastq|--fasta --names "a.fasta;b.fasta.gz;c.fasta" --outdir result file.fastq.gz file.fastq|file.fasta file.fasta.gz
parameters:
    --fasta  Input files are fasta format.
    --fastq  Input files are fastq format.
        #Must specify --fastq or --fasta 
    --name   Mark files by this names, named by files' prefix by default.(examplt:'name1;name2;name3;')
    --outdir Output fold, creat automatically if dosn't exist.
    --help   Print this information.
USAGE
}
if($help or (!$fastq && !$fasta) or ($fasta && $fastq)){help();exit;}
if(!-d $outdir ){mkdir $outdir;}
my @files=@ARGV;
my @name;
if($name){
    @name=split(/;/,$name);
}else{
    for(@files){
        my $temp=basename($_);
        my $prefix=(split /\./,$temp)[0];
        push @name,$prefix;
    }
}
#print "@name";exit;
print $fasta?"Inputing Fasta Files...\n":"Inputing Fastq Files...\n";
my %len;
my $count=-1;
if($fastq){
    for my $f (@files){
        $count++;
        if($f=~/gz$/){
            open IN,"gzip -dc $f|" or die("No such file: $f !");
        }else{
            open IN,"$f" or die("No such file: $f !");
        }
        while(<IN>){
            my $seq=<IN>;
            <IN>;<IN>;
            chomp $seq;
            my $length=length($seq);
            push @{$len{$name[$count]}},$length;
        }
    }
}elsif($fasta){
    for my $f (@files){
        $count++;
        if($f=~/gz$/){
            open IN,"gzip -dc $f|" or die("No such file: $f !");
        }else{
            open IN,"$f" or die("No such file: $f !");
        }
        #$/=">";<IN>;$/="\n";
        $/=">";<IN>;
        while(<IN>){
            #$/=">";
            #my $seq=<IN>;
            #chomp $seq;
            chomp;
            my ($id,$seq)=(split /\n/, $_,2)[0,1];
            $seq=~ s/\n//g;
            print "$seq\n";
            #$seq=~s/\n//g;
            my $length=length($seq);
            next if $length==0;
            push @{$len{$name[$count]}},$length;
            #$/="\n";
        }
        $/="\n";
    }
}
my $workbook=Excel::Writer::XLSX->new("$outdir/statistics.xlsx");
my $format_H=$workbook->add_format();
my $format_C=$workbook->add_format();
my $format=$workbook->add_format();
$format_H->set_bold();
$format_H->set_align('right');#rownames
$format_C->set_bold();
$format_C->set_align('left');#colnames
$format->set_align('right');#body
$format->set_format_properties(font=>'Times New Roman');
$format_H->set_format_properties(font=>'Times New Roman');
$format_C->set_format_properties(font=>'Times New Roman');
=cut
my $counter=-1;
for(@name){
    $counter++;
    $worksheet->write(0,$counter,$_,$format_H);
}
my $counter_C=-1;
for my $it0 (keys %len){
    $counter_C++;
    my $counter_R=0;
    for my $it1 (@{$len{$it0}}){
        $counter_R++;
        $worksheet->write($counter_R,$counter_C,$it1,$format);
    }
}
=cut
my $worksheet=$workbook->add_worksheet("Statistics");
my $counter=-1;
my @StatColNames=("Category","Base Num","Reads Num","  >=2K Reads Num","  >=2K Base num","  >=5K Reads Num","  >=5K Base Num","  >=7K Reads Num","  >=7K Base Num","  >=10K Reads Num","  >=10K Base Num","  >=13K Reads Num","  >=13K Base num","  >=15K Reads Num","  >=15K Base num","Mean Lenth","N50","Middle Length");
for(@StatColNames){
    $counter++;
    $worksheet->write($counter,0,$_,$format_C);
}
$counter=0;
for(@name){
    $counter++;
    $worksheet->write(0,$counter,$_,$format_H);
}
my @MIDDLEn;my @MIDDLEv;
my $counter_C=0;
open OUT,">$outdir/len.bar.table";
open OUT1,">$outdir/len.table";
for my $it (keys %len){
    my @array=@{$len{$it}};
    @array=sort{$b<=>$a}@array;
    my $DV=sum(@array);
    my $RT=scalar(@array);
    my $AL=sprintf("%.2f",$DV/$RT/1000);
    my $L=ceil($RT/2);my $R=floor($RT/2);
    my $ML=sprintf("%.2f",($array[$L]+$array[$R])/2/1000);
    push @MIDDLEn,"\"$it\"";push @MIDDLEv,($array[$L]+$array[$R])/2;
    my ($total_l,%hash,%table,$N50);
    for(@array){
        print OUT1 "$it\t$_\n";
        my $temp=ceil($_/1000)*1000;
        $table{$temp}[0]++;
        $table{$temp}[1]+=$_;
        $total_l+=$_;
        if($_>=2000){
            $hash{2000}[0]+=1;
            $hash{2000}[1]+=$_;
        }
        if($_>=5000){
            $hash{5000}[0]+=1;
            $hash{5000}[1]+=$_;
        }
        if($_>=7000){
            $hash{7000}[0]+=1;
            $hash{7000}[1]+=$_;
        }
        if($_>=10000){
            $hash{10000}[0]+=1;
            $hash{10000}[1]+=$_;
            }
        if($_>=13000){
            $hash{13000}[0]+=1;
            $hash{13000}[1]+=$_;
        }
        if($_>=15000){
            $hash{15000}[0]+=1;
            $hash{15000}[1]+=$_;
        }
        unless($N50){
            if($total_l>=$DV/2){
                $N50=sprintf("%.2f",$_/1000);
            }
        }
    }
    my @temp=(&qian($DV),&qian($RT),&qian($hash{2000}[0])." (".sprintf("%.2f",$hash{2000}[0]/$RT*100)."%)",&qian($hash{2000}[1])." (".sprintf("%.2f",$hash{2000}[1]/$DV*100)."%)",&qian($hash{5000}[0])." (".sprintf("%.2f",$hash{5000}[0]/$RT*100)."%)",&qian($hash{5000}[1])." (".sprintf("%.2f",$hash{5000}[1]/$DV*100)."%)",&qian($hash{7000}[0])." (".sprintf("%.2f",$hash{7000}[0]/$RT*100)."%)",&qian($hash{7000}[1])." (".sprintf("%.2f",$hash{7000}[1]/$DV*100)."%)",&qian($hash{10000}[0])." (".sprintf("%.2f",$hash{10000}[0]/$RT*100)."%)",&qian($hash{10000}[1])." (".sprintf("%.2f",$hash{10000}[1]/$DV*100)."%)",&qian($hash{13000}[0])." (".sprintf("%.2f",$hash{13000}[0]/$RT*100)."%)",&qian($hash{13000}[1])." (".sprintf("%.2f",$hash{13000}[1]/$DV*100)."%)",&qian($hash{15000}[0])." (".sprintf("%.2f",$hash{15000}[0]/$RT*100)."%)",&qian($hash{15000}[1])." (".sprintf("%.2f",$hash{15000}[1]/$DV*100)."%)",$AL."k",$N50."k",$ML."k");
    $counter_C++;
    my $counter_R=0;
    for(@temp){
        $counter_R++;
        $worksheet->write($counter_R,$counter_C,$_,$format);
    }
    my $table_c=-1;
    for(keys %table){
        print OUT "$it\t$_\t$table{$_}[0]\t$table{$_}[1]\n";
    }
}
$workbook->close();
close OUT;
close OUT1;
my @MIDDLE=(@MIDDLEn,@MIDDLEv);
my $middle=join(",",@MIDDLE);
open R,">$outdir/shell.R";
print R <<R;
m<-matrix(c($middle),ncol=2)
df<-read.table("len.bar.table",col.names=c("category","ReadLen","Frequency","BaseNum"))
library("ggplot2")
pdf("frequency.pdf")
ggplot(df,aes(x=ReadLen,y=Frequency),colors=category)+geom_bar(stat="identity",fill="steelblue")+facet_grid(category~.,scales="free_y")+xlim(0,50000)
dev.off()
pdf("Datavolume.pdf")
ggplot(df,aes(x=ReadLen,y=BaseNum),colors=category)+geom_bar(stat="identity",fill="steelblue")+facet_grid(category~.,scales="free_y")+xlim(0,50000)
dev.off()
df<-read.table("len.table")
max<-quantile(df\$V2,0.99)
pdf("Boxplot.pdf")
ggplot(df,aes(x=V1,y=V2,fill=V1))+geom_boxplot(show.legend=F,outlier.shape = NA)+labs(x="Category",y="Length")+ylim(0,max)
dev.off()
R
close R;
`cd $outdir;export R_LIBS="/dellfsqd1/ST_OCEAN/ST_OCEAN/USRS/haoshijie/software/R_LIB";/share/app/R-3.4.1/bin/Rscript shell.R`;

#######################################################################################################################
sub qian{
    my $num=shift;
    while($num =~ s/(\d)(\d{3})((:?,\d\d\d)*)$/$1,$2$3/){
    }
    return $num;
}
