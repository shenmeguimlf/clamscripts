#!/usr/bin/perl -w
use strict;
use Getopt::Long;
use FindBin qw($Bin $RealBin);
use Cwd qw(abs_path getcwd);
use File::Basename qw(dirname basename);

my ($valid,$inputfq1,$inputfq2,$outfq1,$outfq2);
GetOptions(
        "i:s" => \$valid,
        "1:s" => \$inputfq1,
        "2:s" => \$inputfq2,
        "3:s" => \$outfq1,
        "4:s" => \$outfq2,
        );


unless($valid && $inputfq1 && $inputfq2 && $outfq1 && $outfq2){
    &usage;
    exit;
}
if( $valid =~ /\.gz$/ ){
    open LIST,"gzip -dc $valid | " or die "$!\n";
}else{
    open LIST,"$valid" or die "$!\n";
}
my %mark;
while(<LIST>){
    chomp;
    my $id = '@' . (split /\t/,$_)[0];
    $id =~ s/\/\d+$//;
    $mark{$id} = 1;
}
close LIST;

my @fqfile = ($inputfq1,$inputfq2);
my @outfile = ($outfq1,$outfq2);
if( $inputfq1 =~ /\.gz$/ ){
    open FQA,"gzip -dc $inputfq1 | " or die "$!\n";
}else{
    open FQA,"$inputfq1" or die "$!\n";
}
if( $outfq1 =~ /\.gz$/ ){
    open OUA,"| gzip > $outfq1" or die "$!\n";
}else{
    open OUA,"| gzip > $outfq1.gz" or die "$!\n"; 
}
if( $inputfq2 =~ /\.gz$/ ){
    open FQB,"gzip -dc $inputfq2 | " or die "$!\n";
}else{
    open FQB,"$inputfq2" or die "$!\n";
}
if( $outfq2 =~ /\.gz$/ ){
    open OUB,"| gzip > $outfq2" or die "$!\n";
}else{
    open OUB,"| gzip > $outfq2.gz" or die "$!\n"; 
}
while(<FQA>){
    chomp;
    my $id = (split /\s+/,$_)[0];
    $id =~ s/\/\d+$//;
    my $seq1 = <FQA>;
    my $strand1 = <FQA>;
    my $qual1 = <FQA>;
    my $name2 = <FQB>;
    my $seq2 = <FQB>;
    my $strand2 = <FQB>;
    my $qual2 = <FQB>;
    next unless( exists $mark{$id} );
    print OUA "$_\n$seq1$strand1$qual1";
    print OUB "$name2$seq2$strand2$qual2";
}
close FQA;
close OUA;
close FQB;
close OUB;

sub usage{
    print STDERR "\e[;32;1m

    OPTIONS
    -i  valid pair list
    -1  read1
    -2  read2
    -3  output r1
    -4  output r2

    VERSION 1.0 Fri Jun  2 09:11:13 CST 2017
    AUTHOR  Yang Xianwei <yangxianwei1988\@gmail.com>\e[0m
    \n";
}


