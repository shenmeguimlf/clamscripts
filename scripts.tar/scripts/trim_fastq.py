import gzip
import argparse


def read_file(args):
    if not args.fq.endswith('gz'):
        f = open(args.fq, 'r')
        out_fq = open(args.output, 'w')
        deal_fastq(f, args, out_fq)
    else:
        print('gzip fastq')
        f = gzip.open(args.fq, 'rt')
        out_fq = gzip.open(args.output, 'wt')
        deal_fastq(f, args, out_fq)
    f.close()
    out_fq.close()


def deal_fastq(f, args, out_fq_gz):
    fq_infos = []
    for i in f:
        if i.startswith(args.flag):
            if len(fq_infos) == 4:
                write_fq_gz(fq_infos, out_fq_gz, args)
            fq_infos = []
            fq_infos.append(i.strip())
            continue
        else:
            fq_infos.append(i.strip())
    if len(fq_infos) == 4:
        write_fq_gz(fq_infos, out_fq_gz, args)


def write_fq_gz(fq_infos, out_fq_gz, args):
    if len(fq_infos[1]) != len(fq_infos[3]):
        print(fq_infos)
    if len(fq_infos[1]) == len(fq_infos[3]):
        write_fq_info(fq_infos, out_fq_gz, args)
    else:
        pass


def write_fq_info(fq_infos, out_fq_gz, args):
    w = out_fq_gz
    for i, v in enumerate(fq_infos):
        if i == 1 or i == 3:
            v = v[args.s - 1: args.e - 1]
        w.write(v + '\n')


def args_parse():
    parser = argparse.ArgumentParser(
        description='Trim fastq from start to end.',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    parser.add_argument("-s", help="start pos", required=True, type=int)
    parser.add_argument("--flag", help="unique flag of @ line", required=True)
    parser.add_argument("--fq", help="fastq file", required=True)
    parser.add_argument("-e", help="end pos", required=True, type=int)
    parser.add_argument("--output", help="output_file", required=True)
    args = parser.parse_args()
    return args


if __name__ == '__main__':
    args = args_parse()
    read_file(args)
